#set( $CamelCaseName = "" )
#set( $part = "" )
#foreach($part in $NAME.split("-"))
  #set( $CamelCaseName = "${CamelCaseName}$part.substring(0,1).toUpperCase()$part.substring(1).toLowerCase()" )
#end
import React from "react";

export const ${CamelCaseName}: React.FC = () => {
    return <div>${CamelCaseName}</div>;
};
